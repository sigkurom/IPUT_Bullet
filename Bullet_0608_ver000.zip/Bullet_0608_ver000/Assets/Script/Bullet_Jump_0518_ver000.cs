using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Bullet_Jump_0518_ver000 : MonoBehaviour
{
    private CharacterController controller;
    private Vector3 moveDirection;

    // Start is called before the first frame update
    void Start()
    {
        controller = GetComponent<CharacterController>();
    }

    // Update is called once per frame
    void Update()
    {
        if (controller.isGrounded)
        { //�n�ʂɂ��Ă��邩����
            if (Input.GetMouseButtonDown(0))
            {
                moveDirection.y = 20; //�W�����v����x�N�g���̑��
            }
        }
        moveDirection.y -= 10 * Time.deltaTime; //�d�͌v�Z
        controller.Move(moveDirection * Time.deltaTime); //cube�𓮂�������
    }
}
