using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class SceneTransition : MonoBehaviour
{
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        //シフトボタンでシーン遷移
        if (Input.GetKeyDown(KeyCode.Mouse0))
        {
            //スペースキー押した時に効果音
            GetComponent<AudioSource>().Play();
            
            
            //メニュー画面へ
            //SceneManager.LoadScene("　ここに遷移先のシーン名　");
        }
    }
}
